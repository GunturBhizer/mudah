npm i fake-useragent
npm i gradient-string
python bot.py